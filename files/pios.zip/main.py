import utime

rn = range(0,4)
r10 = range(0,100)
for i in rn:
    utime.sleep(0.5)
    print('hide')
    utime.sleep(0.5)
    print('show')
  
print('hide')
for i in r10:
    print('h')
    print('il')
    print('pd')
    for i in rn:
        print('f50')
        print('r90')
    print('ul')
    utime.sleep(0.1)
    print('pw5')
    print('r90')
    print('scwhite')
    print('f50')
    print('pu')
    print('l90')
    print('scblack')
    print('f50')
    print('l90')
    print('f3')
    print('pd')
    print('f44')
    print('pw1')
    print('pu')
    print('f3')
    print('l90')
    print('f45')
    print('r180')
    
while True:
    print('hide')
    utime.sleep(0.5)
   
    utime.sleep(0.5)